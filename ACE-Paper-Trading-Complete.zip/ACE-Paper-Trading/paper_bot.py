#!/usr/bin/env python3
"""A one-symbol, long-only paper trading engine. No network or broker access."""

import argparse
import csv
import hashlib
import json
import sqlite3
import sys
import time
from contextlib import closing
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN, getcontext
from pathlib import Path

getcontext().prec = 40
D = Decimal
ZERO = D(0)
HUNDRED = D(100)
BPS = D(10_000)
QUANTITY_STEP = D("0.00000001")
FILL_COLUMNS = ("bar_timestamp_utc", "side", "reason", "reference_open", "fill_price",
                "quantity", "fee", "cash_after", "realized_pnl")


class InputError(ValueError):
    """The input is unsafe to replay or resume."""


def decimal_value(value):
    try:
        number = D(str(value))
    except (InvalidOperation, ValueError):
        raise InputError(f"Invalid number: {value!r}") from None
    if not number.is_finite() or abs(number) > D("1e15"):
        raise InputError("Numbers must be finite and no greater than 1e15 in magnitude.")
    return number


@dataclass(frozen=True)
class Config:
    cash: Decimal = D("10000")
    fast: int = 10
    slow: int = 30
    size: Decimal = D("10")
    drawdown: Decimal = D("10")
    fee: Decimal = D("10")
    slippage: Decimal = D("5")

    def validate(self):
        if not 1 <= self.fast < self.slow <= 5000:
            raise InputError("Moving averages must satisfy 1 <= fast < slow <= 5000.")
        if self.cash <= 0:
            raise InputError("Starting cash must be positive.")
        if not ZERO < self.size <= HUNDRED or not ZERO < self.drawdown <= HUNDRED:
            raise InputError("Position size and drawdown must be percentages greater than 0 and at most 100.")
        if not ZERO <= self.fee < BPS or not ZERO <= self.slippage < BPS:
            raise InputError("Fee and slippage must be at least zero and under 10,000 basis points.")
        return self


@dataclass(frozen=True)
class Bar:
    ts: str
    opening: Decimal
    close: Decimal


def timestamp(value):
    text = value.strip()
    try:
        if len(text) == 10:
            dt = datetime.combine(date.fromisoformat(text), datetime.min.time(), tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(text[:-1] + "+00:00" if text.endswith("Z") else text)
        if dt.tzinfo is None:
            raise ValueError
        return dt.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
    except (ValueError, OverflowError):
        raise InputError(f"Invalid timestamp {text!r}; use YYYY-MM-DD or an ISO 8601 timestamp with a timezone.") from None


def load_bars(path, allow_empty=False):
    bars = []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, strict=True)
        if not {"timestamp", "open", "close"}.issubset(reader.fieldnames or []):
            raise InputError("CSV needs timestamp,open,close headers.")
        if len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise InputError("CSV headers must not repeat.")
        for row in reader:
            try:
                if None in row or any(row[k] is None for k in ("timestamp", "open", "close")):
                    raise InputError("Malformed row or missing value.")
                bar = Bar(timestamp(row["timestamp"]), decimal_value(row["open"]), decimal_value(row["close"]))
                if min(bar.opening, bar.close) < D("0.000000000001"):
                    raise InputError("Prices must be at least 0.000000000001.")
                if bars and bar.ts <= bars[-1].ts:
                    raise InputError("Timestamps must be strictly increasing and unique after conversion to UTC.")
                bars.append(bar)
            except InputError as exc:
                raise InputError(f"CSV line {reader.line_num}: {exc}") from None
    if not bars and not allow_empty:
        raise InputError("No price bars found.")
    return bars


@dataclass
class State:
    cash: Decimal
    peak: Decimal
    qty: Decimal = ZERO
    entry_cost: Decimal = ZERO
    realized: Decimal = ZERO
    fees: Decimal = ZERO
    max_dd: Decimal = ZERO
    closes: list = field(default_factory=list)
    rows: int = 0
    last_ts: str = ""
    last_close: Decimal = ZERO
    pending: str = ""
    halted_at: str = ""
    closed_positions: int = 0

    @property
    def equity(self):
        return self.cash + self.qty * self.last_close


def initial_state(config):
    return State(cash=config.cash, peak=config.cash)


def signal(state, config):
    if state.halted_at:
        return "DRAWDOWN_EXIT" if state.qty else ""
    if len(state.closes) < config.slow:
        return ""
    # All closes here are known before the next bar. Cross-multiply the means.
    bullish = sum(state.closes[-config.fast:]) * config.slow > sum(state.closes) * config.fast
    if bullish and not state.qty:
        return "BUY"
    if not bullish and state.qty:
        return "SELL"
    return ""


def apply_bar(state, config, bar, warmup=False):
    """First execute the prior decision at this bar's open, then read this bar's close."""
    fill = None
    decision = state.pending
    state.pending = ""
    slip = config.slippage / BPS
    fee_rate = config.fee / BPS
    if not warmup and decision == "BUY" and not state.qty and not state.halted_at:
        price = bar.opening * (1 + slip)
        budget = state.cash * config.size / HUNDRED
        qty = (budget / (price * (1 + fee_rate))).quantize(QUANTITY_STEP, rounding=ROUND_DOWN)
        if qty:
            gross = qty * price
            fee = gross * fee_rate
            state.entry_cost = gross + fee
            state.cash -= state.entry_cost
            state.qty = qty
            state.fees += fee
            fill = (bar.ts, "BUY", "trend_up", bar.opening, price, qty, fee, state.cash, "")
    elif not warmup and decision in {"SELL", "DRAWDOWN_EXIT"} and state.qty:
        price = bar.opening * (1 - slip)
        qty = state.qty
        gross = qty * price
        fee = gross * fee_rate
        proceeds = gross - fee
        pnl = proceeds - state.entry_cost
        state.cash += proceeds
        state.realized += pnl
        state.fees += fee
        state.closed_positions += 1
        state.qty = state.entry_cost = ZERO
        reason = "drawdown_halt" if decision == "DRAWDOWN_EXIT" else "trend_down"
        fill = (bar.ts, "SELL", reason, bar.opening, price, qty, fee, state.cash, pnl)
    state.closes = (state.closes + [bar.close])[-config.slow:]
    state.rows += 1
    state.last_ts = bar.ts
    state.last_close = bar.close
    state.peak = max(state.peak, state.equity)
    dd = (state.peak - state.equity) / state.peak * HUNDRED
    state.max_dd = max(state.max_dd, dd)
    if dd >= config.drawdown and not state.halted_at:
        state.halted_at = bar.ts
    state.pending = signal(state, config)
    return fill


def replay(bars, config):
    state = initial_state(config)
    fills = []
    for bar in bars:
        fill = apply_bar(state, config, bar)
        if fill:
            fills.append(fill)
    return state, fills


def sample_bars():
    # Fixed price segments with reversals, not quotes or any real asset.
    points = [D(103), D(89), D(122), D(95), D(126), D(108)]
    start = date(2020, 1, 1)
    previous = points[0]
    for i in range(125):
        segment = min(i // 25, 4)
        fraction = D(i % 25) / 25
        close = points[segment] + (points[segment + 1] - points[segment]) * fraction + D((i % 7) - 3) / 4
        opened = max(D(1), previous + D((i % 3) - 1) / 2)
        yield Bar(timestamp((start + timedelta(days=i)).isoformat()), opened, close)
        previous = close


def json_encode(value):
    return json.dumps(value, default=str, sort_keys=True, separators=(",", ":"))


def state_decode(value):
    data = json.loads(value)
    for key in ("cash", "peak", "qty", "entry_cost", "realized", "fees", "max_dd", "last_close"):
        data[key] = D(data[key])
    data["closes"] = [D(number) for number in data["closes"]]
    return State(**data)


def state_open(path, create=False):
    if not create and not path.is_file():
        raise InputError("State database not found. Start watch mode first.")
    return sqlite3.connect(path, timeout=5)


def create_tables(db):
    db.execute("CREATE TABLE IF NOT EXISTS checkpoint (id INTEGER PRIMARY KEY CHECK(id=1), "
               "session TEXT NOT NULL, state TEXT NOT NULL, digest TEXT NOT NULL)")
    db.execute("CREATE TABLE IF NOT EXISTS fills (seq INTEGER PRIMARY KEY, payload TEXT NOT NULL)")


def hash_rows(bars, n):
    digest = hashlib.sha256()
    for i in range(n):
        item = bars[i]
        digest.update((item.ts + "," + str(item.opening.normalize()) + ","
                       + str(item.close.normalize()) + "\n").encode("ascii"))
    return digest.hexdigest()


def watch_once(path, db_path, config):
    if path.resolve() == db_path.resolve():
        raise InputError("The input CSV and state database must be different files.")
    bars = load_bars(path, allow_empty=True)
    session = json_encode({"schema": 1, "source": str(path.resolve()), "config": asdict(config)})
    with closing(state_open(db_path, create=True)) as db, db:
        db.execute("BEGIN IMMEDIATE")
        create_tables(db)
        saved = db.execute("SELECT session, state, digest FROM checkpoint WHERE id=1").fetchone()
        fills = []
        if saved:
            saved_session, raw, prefix = saved
            if saved_session != session:
                raise InputError("This database belongs to a different CSV path or configuration. Use a new --state file.")
            state = state_decode(raw)
            if len(bars) < state.rows or hash_rows(bars, state.rows) != prefix:
                raise InputError("Previously processed CSV rows were removed or changed. Restore the input or use a new --state file.")
            if len(bars) == state.rows:
                return state, fills, False
            for bar in bars[state.rows:]:
                fill = apply_bar(state, config, bar)
                if fill:
                    fills.append(fill)
        else:
            state = initial_state(config)
            for bar in bars:
                apply_bar(state, config, bar, warmup=True)
        db.executemany("INSERT INTO fills (payload) VALUES (?)", [(json_encode(fill),) for fill in fills])
        db.execute("INSERT OR REPLACE INTO checkpoint VALUES (1, ?, ?, ?)",
                   (session, json_encode(asdict(state)), hash_rows(bars, len(bars))))
        return state, fills, saved is None


def read_session(path):
    with closing(state_open(path)) as db:
        db.execute("BEGIN")
        saved = db.execute("SELECT session, state FROM checkpoint WHERE id=1").fetchone()
        if not saved:
            raise InputError("State database has no checkpoint.")
        rows = [json.loads(item[0]) for item in db.execute("SELECT payload FROM fills ORDER BY seq")]
        return json.loads(saved[0]), state_decode(saved[1]), rows


def write_csv(path, headers, rows):
    # Exclusive creation protects existing input files and prior reports.
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def print_fill(fill):
    ts, side, reason, _, price, qty, fee, *_ = fill
    print(f"PAPER {side:4}  {ts}  {D(qty):.8f} units @ {D(price):.6f}  fee {D(fee):.4f}  ({reason})", flush=True)


def print_state(state, starting_cash):
    pct = (state.equity / starting_cash - 1) * HUNDRED
    print(f"Bars: {state.rows} | Cash: {state.cash:,.2f} | Equity: {state.equity:,.2f} | "
          f"Return: {pct:+.2f}% | Max close-to-close drawdown: {state.max_dd:.2f}%", flush=True)
    print(f"Position: {state.qty:.8f} units | Realized P&L: {state.realized:+,.2f} | "
          f"Fees: {state.fees:,.2f} | Closed positions: {state.closed_positions}", flush=True)
    print(f"Last bar: {state.last_ts or 'none'} | Next-bar action: {state.pending or 'none'} | "
          f"Drawdown halt: {state.halted_at or 'not triggered'}", flush=True)


def parser():
    root = argparse.ArgumentParser(description=__doc__)
    modes = root.add_subparsers(dest="mode", required=True)
    for name, help_text in (
        ("demo", "run once on built-in synthetic prices"),
        ("replay", "replay all completed bars from a CSV"),
        ("watch", "poll a growing CSV; save simulated trades and resume from a local database"),
    ):
        p = modes.add_parser(name, help=help_text)
        if name != "demo":
            p.add_argument("csv", type=Path)
        p.add_argument("--cash", default="10000", help="starting quote currency, default 10000")
        p.add_argument("--fast", type=int, default=10, help="fast moving average in bars")
        p.add_argument("--slow", type=int, default=30, help="slow moving average in bars")
        p.add_argument("--size-pct", default="10", help="entry allocation as a percent of available cash, fees included")
        p.add_argument("--drawdown-pct", default="10", help="halt threshold from peak close-marked account equity")
        p.add_argument("--fee-bps", default="10", help="simulated per-side fee in basis points")
        p.add_argument("--slippage-bps", default="5", help="simulated adverse slippage in basis points")
        if name == "watch":
            p.add_argument("--state", type=Path, default=Path("paper-state.sqlite3"))
            p.add_argument("--interval", type=int, default=10, help="seconds between CSV checks, minimum 1")
            p.add_argument("--once", action="store_true", help="process input once and exit")
        else:
            p.add_argument("--fills", type=Path, help="export fills to a new CSV")
            if name == "demo":
                p.add_argument("--prices", type=Path, help="export the demo price bars to a new CSV")
    for name, help_text in (("status", "show the saved account"), ("export", "export saved fills to a new CSV")):
        p = modes.add_parser(name, help=help_text)
        p.add_argument("--state", type=Path, default=Path("paper-state.sqlite3"))
        if name == "export":
            p.add_argument("output", type=Path)
    return root


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.mode in {"status", "export"}:
            info, state, rows = read_session(args.state)
            if args.mode == "export":
                write_csv(args.output, FILL_COLUMNS, rows)
                print(f"Exported {len(rows)} simulated fills to {args.output}.")
            else:
                print(f"PAPER session | {info['source']} | Simulated fills: {len(rows)}")
                print_state(state, D(info["config"]["cash"]))
            return 0
        config = Config(decimal_value(args.cash), args.fast, args.slow, decimal_value(args.size_pct),
                        decimal_value(args.drawdown_pct), decimal_value(args.fee_bps),
                        decimal_value(args.slippage_bps)).validate()
        if args.mode != "watch":
            demo = args.mode == "demo"
            print("PAPER ONLY | " + ("Synthetic demo data" if demo else "Historical CSV replay"))
            bars = list(sample_bars()) if demo else load_bars(args.csv)
            prices_output = args.prices if demo else None
            if prices_output is not None and args.fills is not None and prices_output.resolve() == args.fills.resolve():
                raise InputError("Price and fill exports must use different files.")
            state, fills = replay(bars, config)
            for fill in fills:
                print_fill(fill)
            print_state(state, config.cash)
            if args.fills is not None:
                write_csv(args.fills, FILL_COLUMNS, fills)
            if prices_output is not None:
                write_csv(prices_output, ("timestamp", "open", "close"),
                          ((bar.ts, bar.opening, bar.close) for bar in bars))
            return 0

        if args.interval < 1:
            raise InputError("Poll interval must be at least one second.")
        print(f"PAPER ONLY | Watching {args.csv.resolve()} | No orders will be sent.", flush=True)
        last_rows = -1
        while True:
            state, fills, fresh = watch_once(args.csv, args.state, config)
            if fresh:
                print(f"Warmed up on {state.rows} existing bars without fills.", flush=True)
            for fill in fills:
                print_fill(fill)
            if state.rows != last_rows:
                print_state(state, config.cash)
                last_rows = state.rows
            if args.once:
                return 0
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nPaper bot stopped. The last committed checkpoint is saved.", file=sys.stderr)
        return 130
    except (InputError, OSError, UnicodeError, csv.Error, sqlite3.Error, InvalidOperation) as exc:
        print(f"Stopped without submitting orders: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
