# Paper Trading Bot

This is a local Python program for trying an automated trading rule on one instrument at a time. It uses a simulated cash account, never connects to a broker or sends real orders, and does not include a live price feed. It uses only the Python standard library.

## Try it in a minute

Unzip the download. Open a terminal in the extracted `paper-trading-bot` folder and run this with Python 3.10 or newer. On Windows, use `py` instead of `python3` if that is how Python is installed.

```sh
python3 paper_bot.py demo
```

The demo uses invented prices to exercise the buy and sell paths. Its results are not an estimate of what the strategy might earn.

To create a sample CSV for the replay command, run `python3 paper_bot.py demo --prices sample-prices.csv`. That file is synthetic too and won’t update on its own in watch mode.

## Use your own price data

Export one symbol’s completed price bars to a CSV, oldest first, with these columns. Use the same interval, quote currency, and price adjustment convention for every row. The example below shows the format, not a sufficient dataset for the default 30-bar warm-up.

```csv
timestamp,open,close
2026-01-02,100,102
2026-01-05,103,101
```

For intraday data, use a timezone-aware bar-opening timestamp such as `2026-01-05T14:30:00Z`. Use only completed bars. Do not mix symbols, overwrite earlier bars, or add duplicate timestamps.

- **Replay:** Process the full price history once. The optional fills export must be a new file.
  ```sh
  python3 paper_bot.py replay prices.csv --fills replay-fills.csv
  ```
- **Watch:** Poll for new rows while the process is running. The first run uses existing rows to warm up the strategy without creating past fills. Your own data exporter must keep the CSV up to date. Prefer writing a complete updated CSV to a temporary file and replacing the original atomically to prevent partial reads.
  ```sh
  python3 paper_bot.py watch prices.csv --state my-paper-session.sqlite3
  ```
- **Resume and review:** Stop watch mode with `Ctrl+C` and restart with the same command. The bot resumes from its saved checkpoint and will not log the same bar twice. Use a new database if you change strategy settings or start a different ticker.
  ```sh
  python3 paper_bot.py status --state my-paper-session.sqlite3
  python3 paper_bot.py export my-paper-fills.csv --state my-paper-session.sqlite3
  ```

For a one-time update to a watch session, add `--once`. Run `python3 -m unittest -v` to test the engine, CSV validation, and watch loop.

## How the simulation works

- **Signal:** Once 30 closes are available, it compares the last 10 closes with the last 30. It holds one long position when the shorter average is higher and exits otherwise. Adjust the windows with `--fast` and `--slow`. There is no shorting or leverage.
- **Timing:** Decisions use only information through the current bar’s close. A simulated fill uses the following bar’s opening price, plus adverse slippage, and cannot use the signal bar’s own open. In watch mode, that fill is recorded when the next completed bar arrives. Delayed CSV updates can therefore produce reconstructed paper fills, not trades you could actually have executed at that time. If the file ends before a pending action can fill, the bot reports it without inventing a fill.
- **Defaults:** The simulated account starts with 10,000 units of quote currency, allocates up to 10% of cash per entry including fees, and applies 10 basis points of fees and 5 basis points of slippage per side. These are editable modeling inputs, not a venue’s current charges or a recommendation. Use `--cash`, `--size-pct`, `--fee-bps`, and `--slippage-bps` to change them.
- **Drawdown halt:** By default, a 10% drop from peak account equity, measured at a bar close, disables new entries for the session and queues an exit at the next bar’s simulated open. Use `--drawdown-pct` to change the trigger. This is not a guaranteed loss cap: gaps, fees, missing bars, and the delayed simulated exit can lead to larger losses.
- **Results:** The summary shows realized profit or loss, cash, fees, drawdown, and ending equity marked at the last close. A remaining position stays open in the simulation. Fractional quantities use a fixed eight-decimal precision; the bot does not model broker lot sizes, partial fills, market impact, dividends, or taxes.

The strategy is a starting point for testing, not a trading recommendation. A replay result does not establish how it would perform with real money.


## ACE web dashboard

This project includes `dashboard.py`, a Streamlit dashboard for the paper bot's SQLite session. It runs in read-only mode when displaying an existing session. If no database exists, the dashboard offers a synthetic demo session built from invented sample prices. The demo is not a live price feed.

### Run locally

```sh
python -m pip install -r requirements.txt
python -m streamlit run dashboard.py
```

### Deploy from GitHub

Upload the files in this folder to a GitHub repository. In Streamlit Community Cloud, create an app using that repository, branch `main`, and entrypoint `dashboard.py`. The dashboard can create a synthetic demo session when first opened.

**Important:** This bot has no live data feed. Its watch mode needs a separate process that updates a completed-bar CSV. Streamlit Community Cloud's local filesystem is not durable storage; a session database created inside the hosted app may be lost when the app restarts or is redeployed. Do not use it as a persistent trading ledger.
