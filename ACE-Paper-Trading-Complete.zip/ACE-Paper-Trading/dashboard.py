from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="ACE Paper Trading", page_icon="📈", layout="wide")
st.markdown("""
<style>
    .stApp { background: #0b1020; color: #e7edf7; }
    [data-testid="stMetric"] { background: #141d30; border: 1px solid #26344d; padding: 16px; border-radius: 14px; }
    [data-testid="stMetricLabel"] { color: #9eacc3; }
    h1, h2, h3 { color: #f4f7fb; }
    .subtle { color: #9eacc3; }
</style>
""", unsafe_allow_html=True)

st.title("📈 ACE Paper Trading Dashboard")
st.caption("SIMULATION ONLY · Synthetic demo data until you provide your own completed price bars · No broker connection or real orders")

with st.sidebar:
    st.header("Dashboard settings")
    db_path = st.text_input("SQLite session file", value="paper-state.sqlite3")
    st.caption("This dashboard reads the paper bot's SQLite session. Hosted files may reset when the app restarts.")

path = Path(db_path).expanduser()

if not path.is_file():
    st.info("No saved paper-trading session found. Create a sample session to preview the dashboard.")
    if st.button("Create synthetic demo session", type="primary"):
        try:
            import csv
            from paper_bot import Config, sample_bars, watch_once
            bars = list(sample_bars())
            csv_path = path.with_name("ace-synthetic-demo-prices.csv")
            path.parent.mkdir(parents=True, exist_ok=True)
            if csv_path.exists():
                csv_path.unlink()
            # First batch warms up the strategy; the next batch is processed normally.
            with csv_path.open("w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["timestamp", "open", "close"])
                for bar in bars[:30]:
                    writer.writerow([bar.ts, str(bar.opening), str(bar.close)])
            watch_once(csv_path, path, Config())
            with csv_path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                for bar in bars[30:]:
                    writer.writerow([bar.ts, str(bar.opening), str(bar.close)])
            watch_once(csv_path, path, Config())
            st.success("Synthetic demo session created. It uses invented prices, not live market data.")
            st.rerun()
        except Exception as exc:
            st.error(f"Could not create demo session: {exc}")
    st.stop()

try:
    with sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True, timeout=3) as db:
        checkpoint = db.execute("SELECT session, state FROM checkpoint WHERE id=1").fetchone()
        fill_rows = db.execute("SELECT payload FROM fills ORDER BY seq DESC").fetchall()
except sqlite3.Error as exc:
    st.error(f"Could not read this database: {exc}")
    st.stop()

if not checkpoint:
    st.warning("This database exists but does not contain a saved paper-trading checkpoint yet.")
    st.stop()

session = json.loads(checkpoint[0])
state = json.loads(checkpoint[1])
config = session.get("config", {})
fills = [json.loads(row[0]) for row in reversed(fill_rows)]

def number(key, default=0):
    try:
        return float(state.get(key, default))
    except (TypeError, ValueError):
        return float(default)

cash = number("cash")
qty = number("qty")
last_close = number("last_close")
equity = cash + qty * last_close
starting = float(config.get("cash", 10000))
realized = number("realized")
fees = number("fees")
max_dd = number("max_dd")
position_value = qty * last_close
is_demo = "synthetic-demo" in session.get("source", "")
if is_demo:
    st.warning("DEMO MODE: all displayed prices are invented sample data. This is not a live market feed.")

st.markdown(f'<p class="subtle">Source: {session.get("source", "Unknown CSV")} · Last processed bar: {state.get("last_ts") or "—"}</p>', unsafe_allow_html=True)
a, b, c, d = st.columns(4)
a.metric("Account equity", f"{equity:,.2f}", f"{equity-starting:+,.2f} vs start")
b.metric("Available cash", f"{cash:,.2f}")
c.metric("Realized P/L", f"{realized:+,.2f}")
d.metric("Open position value", f"{position_value:,.2f}")
e, f, g, h = st.columns(4)
e.metric("Asset quantity", f"{qty:,.8f}")
f.metric("Last recorded close", f"{last_close:,.6f}")
g.metric("Total simulated fees", f"{fees:,.2f}")
h.metric("Maximum drawdown", f"{max_dd:.2f}%")
st.divider()
left, right = st.columns([1.3, 1])
with left:
    st.subheader("Account overview")
    overview = pd.DataFrame({"Category": ["Cash", "Open position"], "Value": [cash, position_value]}).set_index("Category")
    st.bar_chart(overview)
    st.caption("Open position value is estimated from the last recorded close.")
with right:
    st.subheader("Bot status")
    status = "HALTED — drawdown threshold reached" if state.get("halted_at") else ("POSITION OPEN" if qty else "FLAT — no open position")
    st.metric("Current status", status)
    st.write(f"**Bars processed:** {state.get('rows', 0):,}")
    st.write(f"**Closed positions:** {state.get('closed_positions', 0):,}")
    st.write(f"**Pending decision:** {state.get('pending') or 'None'}")
    st.write(f"**Halted at:** {state.get('halted_at') or 'Not halted'}")
st.divider()
st.subheader("Simulated trade history")
if fills:
    columns = ["bar_timestamp_utc", "side", "reason", "reference_open", "fill_price", "quantity", "fee", "cash_after", "realized_pnl"]
    frame = pd.DataFrame(fills, columns=columns)
    frame["bar_timestamp_utc"] = pd.to_datetime(frame["bar_timestamp_utc"], utc=True, errors="coerce")
    for col in ["reference_open", "fill_price", "quantity", "fee", "cash_after", "realized_pnl"]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    st.dataframe(frame.sort_values("bar_timestamp_utc", ascending=False), use_container_width=True, hide_index=True)
    st.download_button("Download trade history CSV", frame.to_csv(index=False).encode("utf-8"), file_name="ace-paper-trades.csv", mime="text/csv")
else:
    st.info("No simulated fills have been recorded in this session yet.")
with st.expander("Strategy configuration"):
    st.json(config)
    st.caption("These are simulation settings saved by the paper bot. This dashboard does not change the strategy.")
st.caption("Paper-trading results are hypothetical. Historical or simulated performance does not predict future results.")
