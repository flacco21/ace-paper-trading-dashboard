import csv
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from decimal import Decimal as D
from pathlib import Path

from paper_bot import (
    Bar, Config, InputError, apply_bar, initial_state, load_bars, read_session,
    replay, sample_bars, timestamp, watch_once, write_csv,
)

DIRECTORY = Path(__file__).resolve().parent
CONFIG = Config(cash=D(1000), fast=1, slow=2, size=D(10),
                drawdown=D(99), fee=D(0), slippage=D(0))
HEADER = ["timestamp", "open", "close"]


def bar(day, opening, close):
    return Bar(timestamp(f"2020-01-{day:02d}"), D(opening), D(close))


class EngineTests(unittest.TestCase):
    def test_signal_uses_closes_then_next_open_and_no_terminal_fill(self):
        inputs = [bar(1, 10, 10), bar(2, 10, 12)]
        state, fills = replay(inputs, CONFIG)
        self.assertEqual(state.pending, "BUY")
        self.assertEqual(fills, [])
        state, fills = replay(inputs + [bar(3, 20, 8), bar(4, 7, 8)], CONFIG)
        self.assertEqual([(f[1], f[4]) for f in fills], [("BUY", D(20)), ("SELL", D(7))])
        self.assertEqual(state.realized, D(-65))
        self.assertEqual(state.equity, D(935))

    def test_position_cap_includes_fee_and_slippage_is_adverse(self):
        c = Config(cash=D(1000), fast=1, slow=2, size=D(100), drawdown=D(99),
                   fee=D(100), slippage=D(100))
        state, fills = replay([bar(1, 10, 10), bar(2, 10, 12),
                               bar(3, 20, 8), bar(4, 7, 8)], c)
        self.assertGreaterEqual(fills[0][7], 0)
        self.assertEqual(fills[0][4], D("20.2"))
        self.assertEqual(fills[1][4], D("6.93"))
        self.assertGreater(state.fees, 0)
        self.assertEqual(state.cash - c.cash, state.realized)

    def test_drawdown_exits_at_next_open_and_blocks_reentry(self):
        c = Config(cash=D(1000), fast=1, slow=2, size=D(100), drawdown=D(5),
                   fee=D(0), slippage=D(0))
        st = initial_state(c)
        self.assertIsNone(apply_bar(st, c, bar(1, 10, 10)))
        self.assertIsNone(apply_bar(st, c, bar(2, 10, 11)))
        self.assertEqual(apply_bar(st, c, bar(3, 10, 8))[1], "BUY")
        self.assertEqual(st.pending, "DRAWDOWN_EXIT")
        self.assertEqual(apply_bar(st, c, bar(4, 5, 10))[1:3], ("SELL", "drawdown_halt"))
        self.assertIsNone(apply_bar(st, c, bar(5, 10, 16)))
        self.assertEqual(st.pending, "")
        self.assertEqual(st.max_dd, D(50))

    def test_demo_is_deterministic_and_contains_buys_and_sells(self):
        a, af = replay(sample_bars(), Config())
        b, bf = replay(sample_bars(), Config())
        self.assertEqual((a, af), (b, bf))
        self.assertEqual({f[1] for f in af}, {"BUY", "SELL"})

    def test_invalid_config_rejected(self):
        with self.assertRaises(InputError):
            Config(fast=30, slow=10).validate()
        with self.assertRaises(InputError):
            Config(size=D(101)).validate()


class InputAndWatchTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.csv_path = Path(self.folder.name) / "input.csv"
        self.db_path = Path(self.folder.name) / "paper.sqlite3"
        write_csv(self.csv_path, HEADER, [
            ("2020-01-01", 10, 10),
            ("2020-01-02", 10, 12),
        ])

    def append(self, row):
        with self.csv_path.open("a", newline="", encoding="utf-8") as handle:
            csv.writer(handle).writerow(row)

    def test_watch_warmup_restarts_and_logs_exactly_once(self):
        state, fills, fresh = watch_once(self.csv_path, self.db_path, CONFIG)
        self.assertTrue(fresh)
        self.assertEqual(fills, [])
        self.assertEqual(state.pending, "BUY")
        self.append(("2020-01-03", 20, 8))
        self.assertEqual(watch_once(self.csv_path, self.db_path, CONFIG)[1][0][1], "BUY")
        self.assertEqual(watch_once(self.csv_path, self.db_path, CONFIG)[1], [])
        self.append(("2020-01-04", 7, 8))
        self.assertEqual(watch_once(self.csv_path, self.db_path, CONFIG)[1][0][1], "SELL")
        _, state, fills = read_session(self.db_path)
        self.assertEqual(len(fills), 2)
        self.assertEqual(state.realized, D(-65))

    def test_watch_refuses_history_or_config_changes(self):
        watch_once(self.csv_path, self.db_path, CONFIG)
        with self.assertRaisesRegex(InputError, "different CSV path or configuration"):
            watch_once(self.csv_path, self.db_path, Config())
        changed = self.csv_path.with_name("updated.csv")
        write_csv(changed, HEADER, [("2020-01-01", 10, 11), ("2020-01-02", 10, 12)])
        changed.replace(self.csv_path)
        with self.assertRaisesRegex(InputError, "removed or changed"):
            watch_once(self.csv_path, self.db_path, CONFIG)
        self.assertEqual(read_session(self.db_path)[1].rows, 2)

    def test_duplicate_utc_and_nonfinite_prices_rejected(self):
        self.append(("2020-01-02T01:00:00+01:00", 11, 11))
        with self.assertRaisesRegex(InputError, "increasing"):
            load_bars(self.csv_path)
        second = self.csv_path.with_name("invalid.csv")
        write_csv(second, HEADER, [("2020-01-01", 10, "NaN")])
        with self.assertRaisesRegex(InputError, "finite"):
            load_bars(second)

    def test_export_never_overwrites(self):
        with self.assertRaises(FileExistsError):
            write_csv(self.csv_path, HEADER, [])
        self.assertEqual(len(load_bars(self.csv_path)), 2)

    def test_cli_demo_export_round_trips_to_replay(self):
        prices = self.csv_path.with_name("sample.csv")
        demo_fills = prices.with_name("demo-fills.csv")
        replay_fills = prices.with_name("replay-fills.csv")
        cli = [sys.executable, str(DIRECTORY / "paper_bot.py")]
        subprocess.run([*cli, "demo", "--prices", str(prices), "--fills", str(demo_fills)],
                       capture_output=True, check=True)
        subprocess.run([*cli, "replay", str(prices), "--fills", str(replay_fills)],
                       capture_output=True, check=True)
        self.assertEqual(demo_fills.read_bytes(), replay_fills.read_bytes())

    def test_continuous_cli_polls_a_new_bar_without_relaunch(self):
        args = [sys.executable, str(DIRECTORY / "paper_bot.py"), "watch", str(self.csv_path),
                "--state", str(self.db_path), "--interval", "1", "--fast", "1", "--slow", "2"]
        with subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) as proc:
            try:
                self._wait_for_rows(proc, 2)
                self.append(("2020-01-03", 20, 13))
                self._wait_for_rows(proc, 3)
                self.assertEqual(read_session(self.db_path)[2][0][1], "BUY")
            finally:
                proc.terminate()
                proc.communicate(timeout=5)

    def _wait_for_rows(self, proc, count):
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline and proc.poll() is None:
            try:
                if self.db_path.is_file() and read_session(self.db_path)[1].rows == count:
                    return
            except (InputError, sqlite3.OperationalError):
                pass
            time.sleep(0.08)
        self.fail(f"Bot failed to checkpoint {count} bars; exit status {proc.poll()}.")


if __name__ == "__main__":
    unittest.main()
